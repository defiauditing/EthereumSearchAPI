#from cProfile import run
from re import A
from celery import shared_task
import os
import sys
import subprocess
import re
from web.models import Analysis
from django.contrib.auth.models import User
from web.models import AnaysisStatus
from web.query2 import running
def version_installed(v):
    versions = subprocess.getoutput(f"solc-select versions").split("\n")
    for i in versions:
        if v in i :
            return True
    return False

def switch_current_verison(v):
    
    out = subprocess.getoutput(f"solc-select use {v}")
    if "Switched" in out:
        
        return True

    
    return False

def change_object_status(o):
    o.status = AnaysisStatus.COMPLETED
    o.save()
    return o

def get_object(oid):
    obj = Analysis.objects.get(id=oid)
    return obj

@shared_task
def switch(filename,ver,oid):
    
    x = get_object(oid)
    
    
    if not version_installed(ver):
        subprocess.getoutput(f"solc-select install {ver}")
    if switch_current_verison(ver):
        try:
            output = subprocess.check_output(
        f"slither {'./files/'+filename} --solc-disable-warnings", stderr=subprocess.STDOUT, shell=True, timeout=30,
        universal_newlines=True)
        except subprocess.CalledProcessError as exc:
            
            if str(exc).split("exit status ")[1] != "8.":
                
                stdout = exc.output 
                
                #print(exc.output)
                li = re.findall(r'(/[\w\s\-\./]*)',stdout)
                li_fun = lambda x: "/".join(x.split("/")[:-1])
                for i in li :
                    stdout = stdout.replace(li_fun(i),"/docker_executor")

                x.stdout = stdout
                x.status = AnaysisStatus.FAILED
                x.save()
                return True 
            with open("/home/fady/soild/error.txt","w") as ff:
                ff.write(str(exc))
            
            #x.status =  AnaysisStatus.FAILED
            #x.save()
            #return True
        stat = running(filename,data=x.data)
        if stat :
            x.status = AnaysisStatus.COMPLETED
        else : 
            with open("/home/fady/soild/error.txt","w") as ff:
                ff.write("inside runnning")
            x.status = AnaysisStatus.FAILED
        x.save()
    else :

        with open("/home/fady/soild/error.txt","w") as ff:
            ff.write("can't switch")
        x.status = AnaysisStatus.FAILED
        x.save()
    return True
